const fileupload = require('express-fileupload')

router.use(fileupload({
    useTempFiles:true
}));

const cloudinary = require('cloudinary').v2;

cloudinary.config({
    cloud_name: 'dwuy6b2qy',
    api_key: proccess.env.cloudinaryapi_key,
    cloudinaryapi_secret: proccess.env.cloudinaryapi_secret
});

const upload = multer({
    
});
router.post("/products", (req,res,next) => {
    const file = req.files.location;
    console.log(file);
    cloudinary.uploader.upload(file.tempFilePath, function(err, result) {
        console.log("Error:", err);
        console.log("Result", result);
    })
});

module.exports = upload;